/* En un vector de cadenas, indicar: */

// a. la cadena mas corta
let cadenas = ["Ronaldo", "Messi", "Benzema", "Sergio Ramos"]

const cadenaCorta = () => {
    
}
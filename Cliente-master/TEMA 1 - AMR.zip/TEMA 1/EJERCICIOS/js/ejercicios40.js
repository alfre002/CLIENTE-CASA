/* Programa una función para devolver la edad de una persona dada su fecha de nacimiento en
este formato dd/mm/aaa. */

